#coding: utf-8
import web
class panelSetup:
    def __init__(self):
        web.header("Server",'Bt-Panel Server')
        web.header("Token-auth",'http://www.bt.cn')
        pass
        
class panelAdmin(panelSetup):
    def __init__(self):
        
        web.ctx.session.brand = '宝塔'
        web.ctx.session.product = 'Linux面板'
        web.ctx.session.version = "3.1.0"
        web.ctx.session.rootPath = '/www'
        web.ctx.session.setupPath = web.ctx.session.rootPath+'/server'
        web.ctx.session.logsPath = web.ctx.session.rootPath+'/wwwlogs'
        
        import os,public
        
        if os.path.exists('data/close.pl'):
            raise web.seeother('/close');
        
        if os.path.exists(web.ctx.session.setupPath + '/nginx'):
            web.ctx.session.webserver = 'nginx'
        else:
            web.ctx.session.webserver = 'apache'
        if os.path.exists(web.ctx.session.setupPath+'/'+web.ctx.session.webserver+'/version.pl'):
            web.ctx.session.webversion = public.readFile(web.ctx.session.setupPath+'/'+web.ctx.session.webserver+'/version.pl').strip()
        
        filename = web.ctx.session.setupPath+'/data/phpmyadminDirName.pl'
        if os.path.exists(filename):
            web.ctx.session.phpmyadminDir = public.readFile(filename).strip()
            
        import public
        try:
            if not web.ctx.session.login:
                raise web.seeother('/login')
            
            tmp = web.ctx.host.split(':')
            domain = public.readFile('data/domain.conf')
            if domain:
                if(tmp[0].strip() != domain.strip()): raise web.seeother('/login')
        except:
            raise web.seeother('/login')
        
        
        web.ctx.session.config = public.M('config').where("id=?",('1',)).field('webserver,sites_path,backup_path,status,mysql_root').find();
        if not hasattr(web.ctx.session.config,'email'):
            web.ctx.session.config['email'] = public.M('users').where("id=?",('1',)).getField('email');
        if not hasattr(web.ctx.session,'address'):
            web.ctx.session.address = public.GetLocalIp()