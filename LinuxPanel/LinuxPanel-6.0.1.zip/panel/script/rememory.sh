#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
#+------------------------------------
#+ 宝塔释放内存脚本
#+------------------------------------

endDate=`date +"%Y-%m-%d %H:%M:%S"`
log="释放内存!"
echo "★[$endDate] $log"
echo '----------------------------------------------------------------------------'

if [ -f "/etc/init.d/php-fpm-52" ];then
	service php-fpm-52 reload
fi

if [ -f "/etc/init.d/php-fpm-53" ];then
	service php-fpm-53 reload
fi

if [ -f "/etc/init.d/php-fpm-54" ];then
	service php-fpm-54 reload
fi

if [ -f "/etc/init.d/php-fpm-55" ];then
	service php-fpm-55 reload
fi

if [ -f "/etc/init.d/php-fpm-56" ];then
	service php-fpm-56 reload
fi

if [ -f "/etc/init.d/php-fpm-70" ];then
	service php-fpm-70 reload
fi

if [ -f "/etc/init.d/php-fpm-71" ];then
	service php-fpm-71 reload
fi

if [ -f "/etc/init.d/mysqld" ];then
	service mysqld reload
fi

if [ -f "/etc/init.d/nginx" ];then
	service nginx reload
fi

if [ -f "/etc/init.d/httpd" ];then
	service httpd graceful
fi

if [ -f "/etc/init.d/pure-ftpd" ];then
	pkill -9 pure-ftpd
	sleep 0.3
	service pure-ftpd start
fi

sync
echo 3 > /proc/sys/vm/drop_caches

echo '----------------------------------------------------------------------------'