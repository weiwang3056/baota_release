# coding: utf-8
# -------------------------------------------------------------------
# 宝塔Linux面板
# -------------------------------------------------------------------
# Copyright (c) 2015-2017 宝塔软件(http:#bt.cn) All rights reserved.
# -------------------------------------------------------------------
# Author: 1249648969@qq.com
# -------------------------------------------------------------------

# ------------------------------
# 数据库工具类
# ------------------------------
import sys, os
os.chdir("/www/server/panel")
sys.path.append('class')
import panelMysql
import re,json

class datatools:
    DB_MySQL = None
    # 字节单位转换
    def ToSize(self, size):
        ds = ['b', 'KB', 'MB', 'GB', 'TB']
        for d in ds:
            if size < 1024: return str(size) + d
            size = size / 1024
        return '0b';

    # 获取当前数据库信息
    def GetdataInfo(self,get):
        '''
        传递一个数据库名称即可 get.databases
        '''
        if not self.DB_MySQL:self.DB_MySQL = panelMysql.panelMysql()
        db_name=get.db_name

        if not db_name:return False
        ret = {}
        tables = self.map_to_list(self.DB_MySQL.query('show tables from %s' % db_name))

        if type(tables) == list:
            if len(tables) >= 1:
                # 查询当前数据库存储空间
                try:
                    data = self.map_to_list(self.DB_MySQL.query("select sum(DATA_LENGTH)+sum(INDEX_LENGTH) from information_schema.tables  where table_schema='%s'" % db_name))[0][0]
                except:
                    data=False
                if data:
                    try:
                        datatype= self.map_to_list(self.DB_MySQL.query("show variables like '%storage_engine%';"))[0][1]
                    except:
                        datatype=False
                    ret['data_type']=datatype
                    data_size = re.findall('(\d+)', str(data))[0]
                    #if data_size<10:continue
                    ret['data_size'] = self.ToSize(int(data_size))
                    ret['database'] = databases

                ret3 = []
                for i in tables:
                    
                    table = self.map_to_list(self.DB_MySQL.query("select sum(INDEX_LENGTH) from information_schema.tables where table_schema='%s' AND table_name='%s';" % (db_name, i[0])))
                    ret2 = {}

                    # 查看当前表的引擎
                    table_type= self.map_to_list(self.DB_MySQL.query("select engine from information_schema.tables where table_schema='%s' and table_name='%s';"%(db_name,i[0])))
                    ret2['type']=table_type[0][0]
                    data_size = re.findall('(\d+)', str(table))[0]
                    ret2['data_size'] = self.ToSize(int(data_size))
                    ret2['table_name'] = i[0]
                    ret3.append(ret2)
                ret['tables'] = (ret3)
            return ret

        else:
            return False


    #修复表信息
    def RepairTable(self,get):
        
        '''
        POST:
        db_name=web
        tables=['web1','web2']
        '''
        db_name = get.db_name
        tables = json.loads(get.tables)
        if not db_name or not tables: return False
        if not self.DB_MySQL:self.DB_MySQL = panelMysql.panelMysql()
        mysql_table = self.map_to_list(self.DB_MySQL.query('show tables from %s' % db_name))
        ret=[]
        if type(mysql_table)==list:
            if len(mysql_table)>1:   
                for i in mysql_table:
                    for i2 in tables:
                        if i2==i[0]:
                            ret.append(i2)
                if len(ret)>1:
                    for i in ret:
                        self.DB_MySQL.execute('REPAIR TABLE %s.%s'%(db_name,i))
                    return True 
        return False



    #map to list
    def map_to_list(self,map_obj):
        if type(map_obj) != list and type(map_obj) != str: map_obj = list(map_obj)
        return map_obj


    # 优化表
    def OptimizeTable(self,get):
        '''
        POST:
        db_name=web
        tables=['web1','web2']
        '''
        if not self.DB_MySQL:self.DB_MySQL = panelMysql.panelMysql()
        db_name = get.db_name
        tables = json.loads(get.tables)
        if not db_name or not tables: return False
        mysql_table = self.map_to_list(self.DB_MySQL.query('show tables from %s' % db_name))
        ret=[]
        if type(mysql_table) == list:
            if len(mysql_table) > 1:
                for i in mysql_table:
                    for i2 in tables:
                        if i2 == i[0]:
                            ret.append(i2)
                if len(ret)>1:
                    for i in ret:
                        self.DB_MySQL.execute('OPTIMIZE table %s.%s ENGINE=MyISAM' % (db_name,i))
                    return True 
        return False

    # 更改表引擎
    def AlterTable(self,get):
        '''
        POST:
        db_name=web
        table_type=innodb
        tables=['web1','web2']
        '''
        if not self.DB_MySQL:self.DB_MySQL = panelMysql.panelMysql()
        db_name = get.db_name
        table_type = get.table_type
        tables = json.loads(get.tables)

        if not db_name or not tables: return False
        
        mysql_table = self.map_to_list(self.DB_MySQL.query('show tables from %s' % db_name))
        ret=[]
        if type(mysql_table)==list:
            if len(mysql_table)>1:   
                for i in mysql_table:
                    for i2 in tables:
                        if i2==i[0]:
                            ret.append(i2)
                if len(ret)>1:
                    for i in ret:
                        self.DB_MySQL.execute('alter table %s.%s ENGINE=%s' % (db_name,i,table_type))
                    return True 
        return False


    #检查表
    def CheckTable(self,database,tables,*args,**kwargs):
        pass
