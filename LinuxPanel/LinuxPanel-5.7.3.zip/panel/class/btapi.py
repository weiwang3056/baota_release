#coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2017 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: 黄文良 <287962566@qq.com>
# +-------------------------------------------------------------------
#
#             ┏┓      ┏┓
#            ┏┛┻━━━━━━┛┻┓
#            ┃               ☃              ┃
#            ┃  ┳┛   ┗┳ ┃
#            ┃     ┻    ┃
#            ┗━┓      ┏━┛
#              ┃      ┗━━━━━┓
#              ┃  神兽保佑              ┣┓
#              ┃ 永无BUG！            ┏┛
#              ┗┓┓┏━┳┓┏━━━━━┛
#               ┃┫┫ ┃┫┫
#               ┗┻┛ ┗┻┛

#------------------------------
# API管理模块
#------------------------------

import sys,os
sys.path.append('/www/server/panel/class');
reload(sys);
import public,web

class site:
    __site = None;
        
    def __init__(self):
        import panelSite;
        if not self.__site: self.__site = panelSite.panelSite();
    #创建网站
    def create(self,siteInfo):
        try:
            import json
            isFtp = 'false';
            if siteInfo['ftp']: isFtp = 'true';
            isData = 'false';
            if siteInfo['database']: isData = 'true';
            data = web.ctx;
            data['webname'] = json.dumps({'domain':siteInfo['name'],'domainlist':siteInfo['domain'],'count':len(siteInfo['domain']) + 1});
            data['ps'] = siteInfo['ps'];
            data['path'] = siteInfo['path'];
            data['port'] = siteInfo['port'];
            data['ftp'] = isFtp;
            data['sql'] = isData;
            data['ftp_username'] = siteInfo['ftp_username'];
            data['ftp_password'] = siteInfo['ftp_password'];
            data['datauser'] = siteInfo['db_username'];
            data['datapassword'] = siteInfo['db_password'];
            data['codeing'] = siteInfo['db_codeing'];
            data['version'] = siteInfo['php_version'];
            return self.__site.AddSite(data);
        except Exception,ex:
            return public.returnMsg(False,'参数错误!' + str(ex));
            
    #删除网站
    def remove(self,siteName,rmdir = False, rmdb = False, rmftp = False):
        try:
            data = web.ctx;
            data.id = public.M('sites').where('name=?',(siteName,)).getField('id');
            if not data.id: return public.returnMsg(False,'指定站点不存在!');
            data.webname = siteName;
            data.ftp = '0';
            data.database = '0';
            data.path = '0';
            if rmdir: data.path = '1';
            if rmdb: data.database = '1';
            if rmftp: data.ftp = '1';
            return self.__site.DeleteSite(data);
        except Exception,ex:
            return public.returnMsg(False,'参数错误!' + str(ex));
        
    #停止网站
    def stop(self,siteName):
        data = web.ctx;
        data.id = public.M('sites').where('name=?',(siteName,)).getField('id');
        if not data.id: return public.returnMsg(False,'指定站点不存在!');
        data.webname = siteName;
        return self.__site.SiteStop(data);
        
    #启动网站
    def start(self,siteName):
        data = web.ctx;
        data.id = public.M('sites').where('name=?',(siteName,)).getField('id');
        if not data.id: return public.returnMsg(False,'指定站点不存在!');
        data.webname = siteName;
        return self.__site.SiteStart(data);
        
    #添加域名
    def add_domain(self,siteName,domains):
        data = web.ctx;
        data.id = public.M('sites').where('name=?',(siteName,)).getField('id');
        if not data.id: return public.returnMsg(False,'指定站点不存在!');
        data.webname = siteName;
        if type(domains) != list: return public.returnMsg(False,'域名参数数据类型必需为list');
        data.domain = ','.join(domains);
        return self.__site.AddDomain(data);
        
    #删除域名
    def remove_domain(self,siteName,domain,port = '80'):
        data = web.ctx;
        data.id = public.M('sites').where('name=?',(siteName,)).getField('id');
        if not data.id: return public.returnMsg(False,'指定站点不存在!');
        data.webname = siteName;
        data.domain = domain;
        data.port = port;
        return self.__site.DelDomain(data);
        
    #开启SSL
    def ssl_on(self,sslInfo):
        pass;
    
    #开启SSL通过G5
    def ssl_on_g5(self,sslInfo):
        pass;
    
    #开启SSL，通过自有证书
    def ssl_on_private(self,sslInfo):
        pass;
    
    #开启SSL，通过Let's
    def ssl_on_lets(self,sslInfo):
        pass;
        
    #关闭SSL
    def ssl_off(self,siteName):
        pass;
    
    #开启反向代理
    def proxy_on(self,proxyInfo):
        pass;
    
    #关闭反向代理
    def proxy_off(self,siteName):
        pass;
    
    #设置运行目录
    def run_path(self,siteName,runPath):
        pass;
    
    #设置根目录
    def set_path(self,siteName,path):
        pass;
    
    #获取配置文件
    def get_conf(self,siteName):
        pass;
    
    #保存配置文件
    def save_conf(self,siteName,conf):
        pass;
    
    #获取网站列表
    def get_list(self,limit):
        pass;
    
    #获取伪静态
    def get_rewrite(self,siteName):
        pass;
    
    #保存伪静态
    def save_rewrite(self,siteName,rewrite):
        pass;
    
    #获取301配置
    def get_301(self,siteName):
        pass;
    
    #设置301重定向
    def set_301(self,siteName,domain,to):
        pass;
    
    #取防盗链配置
    def get_security(self,siteName):
        pass;
    
    #设置防盗链
    def set_security(self,siteName,fix,domains):
        pass
    
    #添加子目录绑定
    def create_binding(self,siteName,domain,path):
        pass
    
    #删除子目录 绑定
    def remove_binding(self,siteName,domain):
        pass
    
    #修改备注
    def ps(self,siteName,ps):
        pass;
    
class database:
    
    #创建数据库
    def create(self,dataInfo):
        pass;
    
    #删除数据库
    def remove(self,dataName):
        pass;
    
    #修改密码
    def password(self,dataName,password):
        pass;
    
    #修改权限
    def access(self,dataName,access):
        pass;
    
    
    #修改备注
    def ps(self,dataName,ps):
        pass;
    

class ftp:
    
    #创建FTP
    def create(self,ftpInfo):
        pass;
    
    #删除FTP
    def remove(self,ftpName):
        pass;
    
    #修改密码
    def password(self,ftpName,password):
        pass;
    
    #停用FTP
    def stop(self,ftpName):
        pass;
    
    #启用FTP
    def start(self,ftpName):
        pass;
    
    #修改备注
    def ps(self,ftpName,ps):
        pass;
    
    
    
    
    