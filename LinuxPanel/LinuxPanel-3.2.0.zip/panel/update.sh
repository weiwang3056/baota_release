#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

setup_path=/www
wget -T 5 -O panel.zip $1
unzip -o panel.zip -d $setup_path/server/ > /dev/null

rm -f panel.zip
cd $setup_patn/server/panel/
rm -f class/*.pyc
rm -f *.pyc
python -m compileall $setup_patn/server/panel
python -m compileall *
python -m compileall class/*
rm -f *.py
rm -f class/*.py